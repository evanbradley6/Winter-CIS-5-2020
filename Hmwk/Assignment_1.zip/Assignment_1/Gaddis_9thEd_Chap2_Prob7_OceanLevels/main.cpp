/* File:   main.cpp 
 * Author: Evan BRadley
 * Created on January 12, 2020, 3:37 PM
 * Purpose:  C++ Template to be copied and utilized
 * for homework, projects, exams!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main() {
    //Set Random Number seed
    const double MIL_PER_YEAR = 1.5;
    
    cout << "The ocean's levels will rise " << MIL_PER_YEAR * 5 << " millimeters " << endl << "after 5 years." << endl;
    cout << "The ocean's levels will rise " << MIL_PER_YEAR * 7 << " millimeters " << endl << "after 7 years." << endl;
    cout << "The ocean's levels will rise " << MIL_PER_YEAR * 10 << " millimeters " << endl << "after 10 years." << endl;
    //Declare Variable Data Types and Constants
    
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}