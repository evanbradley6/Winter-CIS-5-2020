/* 
 * File:   main.cpp
 * Author: Evan Bradley
 * Created on January 10, 2020, 12:36 PM
 * Purpose:  C++ Template to be copied and utilized
 * for homework, projects, exams!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main() {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    cout << endl;
    cout << "     *     " << endl;
    cout << "    ***    " << endl;
    cout << "   *****   " << endl;
    cout << "  *******  " << endl;
    cout << "   *****   " << endl;
    cout << "    ***    " << endl;
    cout << "     *     " << endl;
    cout << endl;
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}