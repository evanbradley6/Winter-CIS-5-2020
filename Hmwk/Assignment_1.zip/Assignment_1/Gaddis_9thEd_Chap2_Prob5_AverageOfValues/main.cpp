/* 
 * File:   main.cpp
 * Author: Evan Bradley
 * Created on January 11, 2020, 11:55 PM
 * Purpose:  C++ Template to be copied and utilized
 * for homework, projects, exams!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main() {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    double a = 28, b = 32, c = 37, d = 24, e = 33,
            sum = a + b + c + d + e,
            average = sum / 5;
    
    cout << endl;
    cout << "The sum of the set of numbers: " << endl 
            << "28, 32, 37, 24, 33 is " << sum 
            << "." << endl; 
    cout << "The average of those same set of numbers is " << endl 
            << average << "."
            << endl;
    
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}