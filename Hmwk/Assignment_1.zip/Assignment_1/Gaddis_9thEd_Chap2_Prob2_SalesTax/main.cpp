/* 
 * File:   main.cpp
 * Author: Evan Bradley
 * Created on January 12, 2020, 3:08 PM
 * Purpose:  C++ Template to be copied and utilized
 * for homework, projects, exams!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main() {
    //Set Random Number seed
    float totSalesPrct = 0.58, totSalesThisYr = 8.6E6,
            totAmtGenerated = totSalesPrct * totSalesThisYr;
    
    cout << endl;
    cout << "If a company has $8.6 million in sales this year "
            << "and generates 58% of the total sales, then that"
            << " company will most likely"
            << "generate $" << totAmtGenerated
            << " in sales." << endl;
    
    //Declare Variable Data Types an Constants
    
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}